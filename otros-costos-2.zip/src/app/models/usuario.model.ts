export interface Usuario{

    id:string,
    email:string,
    nombre:string,
    apellido:string,
    usuario:string,
    userName: string,
    foto: any,
    token: string,
    legajo: any,
    activo: boolean,
    Groups: [],
    errores: []
  }


