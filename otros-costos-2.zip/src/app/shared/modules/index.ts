export { AngularModule } from "./angular.module";
export { MaterialModule } from "./material.module";