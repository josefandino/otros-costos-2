import { Routes } from "@angular/router";
import { AdministracionComponent } from "./administracion.component";

export const administracionRouting : Routes = [
  {
    path: "" , component:AdministracionComponent
  }
]
