import { Component } from '@angular/core';

@Component({
  selector: 'app-cargas',
  standalone: true,
  imports: [],
  templateUrl: './cargas.component.html',
  styleUrl: './cargas.component.scss'
})
export class CargasComponent {

}
