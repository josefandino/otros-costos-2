import { Routes } from "@angular/router";
import { CargasComponent } from "./cargas.component";

export const cargasRouting : Routes = [
  {
    path :"" , component:CargasComponent
  }
]
